<!DOCTYPE html>
	<html lang="en" and dir="ltr">
		<head>
            <meta charset="UTF-8">
            <title>Login</title>
            <link rel="stylesheet" href="style2.css">
            <link rel="stylesheet" href="bankstyle.css">
            <script src="script.js"></script>
        </head>
            <body>
                <form class="box" action="index.php" method="POST">
                    <h1 style="float:none">
                        Wrong Login Details
                    </h1>
                    <input type="Submit" name="" value="Login">
                    <span id="sign up" style="color: white;">don't have an account? <a href="signup.php">Sign Up</a></span>
                </form>
            </body>
    </html>
           