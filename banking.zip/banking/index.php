<!DOCTYPE html>
	<html lang="en" and dir="ltr">
		<head>
            <meta charset="UTF-8">
            <title>Login</title>
            <link rel="stylesheet" href="style2.css">
            <link rel="stylesheet" href="bankstyle.css">
            <script src="script.js"></script>
        </head>
            <body>
                <form class="box" action="bankconfig.php" method="POST">
                    <h1 style="float:none">
                        Login
                    </h1>
                    <input type="text" name="username" placeholder="Enter Username" id="username">
                    <input type="password" name="password" placeholder="Enter Password" id="password">
                    <input type="Submit" name="" value="Login">
                    <span id="sign up" style="color: white;">don't have an account? <a href="signup.php">Sign Up</a></span>
                </form>
            </body>
    </html>
           